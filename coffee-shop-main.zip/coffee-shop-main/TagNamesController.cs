﻿using E_CoffeeShop.Data;
using E_CoffeeShop.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace E_CoffeeShop.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize]

    public class TagNamesController : Controller
    {
        private readonly ApplicationDbContext _db;
        public TagNamesController(ApplicationDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            IEnumerable<TagNames> tagNames = _db.TagNames;
            return View(_db.TagNames.ToList());
        }
        //GET
        public IActionResult Create()
        {
            
            return View();
        }
        //POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(TagNames tagNames)
        {
            if (ModelState.IsValid)
            {
                var searchTagName = _db.TagNames.FirstOrDefault(c => c.TagName == tagNames.TagName);
                if (searchTagName != null)
                {
                    ViewBag.Message= "This tag name already exists.";
                    return View(tagNames);
                }
                _db.TagNames.Add(tagNames);
                await _db.SaveChangesAsync();
                TempData["success"] = "The processing was successfull";
                return RedirectToAction("Index");
            }
            return View(tagNames);
        }
        //GET
        public IActionResult Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var tagNames = _db.TagNames.Find(id);
            if (tagNames == null)
            {
                return NotFound();
            }
            return View(tagNames);
        }
        //POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(TagNames tagNames)
        {
            if (ModelState.IsValid)
            {
                _db.Update(tagNames);
                await _db.SaveChangesAsync();
                TempData["success"] = "The processing was successfull";
                return RedirectToAction("Index");
            }
            return View(tagNames);
        }
        //GET
        public IActionResult Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var tagNames = _db.TagNames.Find(id);
            if (tagNames == null)
            {
                return NotFound();
            }
            return View(tagNames);
        }
        //POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Details(TagNames tagNames)
        {
            return RedirectToAction("Index");

        }
        //GET
        public IActionResult Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var tagNames = _db.TagNames.Find(id);
            if (tagNames == null)
            {
                return NotFound();
            }
            return View(tagNames);
        }
        //POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int? id, TagNames tagNames)
        {
           
            if (id == null)
            {
                return NotFound();
            }
           
            if (id != tagNames.Id)
            {
                return NotFound();
            }
           
            if (tagNames == null)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                _db.Remove(tagNames);
                await _db.SaveChangesAsync();
                TempData["success"] = "The processing was successfull";
                return RedirectToAction("Index");
            }
            return View(tagNames);
        }
    }

}

