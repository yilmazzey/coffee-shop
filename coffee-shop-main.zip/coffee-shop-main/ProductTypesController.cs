﻿using Microsoft.AspNetCore.Mvc;
using E_CoffeeShop.Data;
using E_CoffeeShop.Models;
using Microsoft.AspNetCore.Authorization;

namespace E_CoffeeShop.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize]

    public class ProductTypesController : Controller
    {
        private readonly ApplicationDbContext _db;
        public ProductTypesController(ApplicationDbContext db)
        {
            _db= db;    
        }
        public IActionResult Index()
        {
            IEnumerable<ProductTypes> productTypes = _db.ProductTypes;
            return View(_db.ProductTypes.ToList());
        }
        //GET
         public IActionResult Create()
        {
           
            return View();  
        }
        //POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ProductTypes productTypes)
        {
            if (ModelState.IsValid)
            {
                var searchProductType = _db.ProductTypes.FirstOrDefault(c => c.ProductType == productTypes.ProductType);
                if (searchProductType != null)
                {
                    ViewBag.Message = "This product type alredy exists.";
                    return View(productTypes);
                }
                _db.ProductTypes.Add(productTypes);
                await _db.SaveChangesAsync();
                TempData["success"] = "The processing was successfull";
                return RedirectToAction("Index");
            }
            return View(productTypes);
        }
        //GET
        public IActionResult Edit(int?id)
        {
            if(id == null)
            {
                return NotFound();
            }
            var productTypes = _db.ProductTypes.Find(id);
            if(productTypes == null)
            {
                return NotFound();
            }
            return View(productTypes);
        }
        //POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(ProductTypes productTypes)
        {
            if (ModelState.IsValid)
            {
                _db.Update(productTypes);
                await _db.SaveChangesAsync();
                TempData["success"] = "The processing was successfull";
                return RedirectToAction("Index");
            }
            return View(productTypes);
        }
        //GET
        public IActionResult Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var productTypes = _db.ProductTypes.Find(id);
            if (productTypes == null)
            {
                return NotFound();
            }
            return View(productTypes);
        }
        //POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Details(ProductTypes productTypes)
        {
            return RedirectToAction("Index");
            
        }
        //GET
        public IActionResult Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var productTypes = _db.ProductTypes.Find(id);
            if (productTypes == null)
            {
                return NotFound();
            }
            return View(productTypes);
        }
        //POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int? id,ProductTypes productTypes)
        {
            if (id == null)
            {
                return NotFound();
            }
            if (id != productTypes.Id)
            {
                return NotFound();
            }
            var productType = _db.ProductTypes.Find(id);
            if (productType == null)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                _db.Remove(productType);
                await _db.SaveChangesAsync();
                TempData["success"] = "The processing was successfull";
                return RedirectToAction("Index");
            }
            return View(productTypes);
        }
    }

}

