﻿using Microsoft.AspNetCore.Mvc;
using E_CoffeeShop.Data;
using E_CoffeeShop.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Authorization;

namespace E_CoffeeShop.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize]
    public class ProductController : Controller
    {
        private readonly ApplicationDbContext _db;

        private readonly IWebHostEnvironment _he;
        public ProductController(ApplicationDbContext db, IWebHostEnvironment he)
        {
            _db = db;
            _he = he;
        }
        public IActionResult Index()
        {
            return View(_db.Products.Include(c => c.ProductTypes).Include(f => f.TagNames).ToList());

        }
        //POST Index action method
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Index(decimal? lowAmount, decimal? largeAmount)
        {
            var products=_db.Products.Include(c=>c.ProductTypes).Include(c=> c.TagNames).Where(c=>c.Price>=lowAmount&&c.Price<=largeAmount).ToList();
            if (lowAmount == null || largeAmount == null)
            {
                products = _db.Products.Include(c => c.ProductTypes).Include(c => c.TagNames).ToList();
            }
            return View(products);
        
        }

        //GET
        public IActionResult Create()
        {
            ViewData["ProductTypeId"] = new SelectList(_db.ProductTypes.ToList(), "Id", "ProductType");
            ViewData["SpecialTagId"] = new SelectList(_db.TagNames.ToList(), "Id", "TagName");
            return View();
        }
        //POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Products products, IFormFile image)
        {
            if (!ModelState.IsValid)
            {
                
                if (image != null)
                {
                    var name = Path.Combine(Directory.GetCurrentDirectory(), $"wwwroot/Images/" + Path.GetFileName(image.FileName));
                    await image.CopyToAsync(new FileStream(name, FileMode.Create));
                    products.Image = "Images/" + image.FileName;

                }
                if (image == null)
                {
                    products.Image = "/Images/no-image-icon-23485(1).PNG";
                }
                _db.Products.Add(products);
                await _db.SaveChangesAsync();
                TempData["success"] = "The processing was successfull";
                return RedirectToAction("Index");
            }
            else
            {
                return View(products);
            }

        }

        //GET
        public ActionResult Edit(int? id)
        {
            ViewData["ProductTypeId"] = new SelectList(_db.ProductTypes.ToList(), "Id", "ProductType");
            ViewData["SpecialTagId"] = new SelectList(_db.TagNames.ToList(), "Id", "TagName");
            if (id == null)
            {
                return NotFound();
            }
            var product = _db.Products.Include(c => c.ProductTypes).Include(c => c.TagNames).FirstOrDefault(c => c.Id == id);
            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }
        //POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Products products, IFormFile image)
        {
            if (!ModelState.IsValid)
            {
                if (image != null)
                {
                    var name = Path.Combine(Directory.GetCurrentDirectory(), $"wwwroot/Images/" + Path.GetFileName(image.FileName));
                    await image.CopyToAsync(new FileStream(name, FileMode.Create));
                    products.Image = "Images/" + image.FileName;

                }
                if (image == null)
                {
                    products.Image = "/Images/no-image-icon-23485(1).PNG";
                }
                _db.Products.Update(products);
                await _db.SaveChangesAsync();
                TempData["success"] = "The processing was successfull";
                return RedirectToAction("Index");
            }
            else
            {
                return View(products);
            }
        }
        //GET
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var product = _db.Products.Include(c => c.ProductTypes).Include(c => c.TagNames).FirstOrDefault(c => c.Id == id);
           if(product == null)
            {
                return NotFound();
            }
            return View(product);
        }
        //GET
        public ActionResult Delete(int? id)
        {
           
            if (id == null)
            {
                return NotFound();
            }
            var product = _db.Products.Include(c => c.TagNames).Include(c => c.ProductTypes).Where(c => c.Id == id).FirstOrDefault();
            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }
        //POST
        [HttpPost]
        [ActionName("Delete")]
        
        public async Task<IActionResult> DeleteConfirm(int?id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var product = _db.Products.FirstOrDefault(c => c.Id == id);
            if (product == null)
            {
                return NotFound();
            }
            _db.Products.Remove(product);
            await _db.SaveChangesAsync();   
            return RedirectToAction("Index");
        }


    }
}